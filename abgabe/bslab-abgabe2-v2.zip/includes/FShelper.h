//
// Created by user on 21.11.20.
//
#include "myfs-structs.h"

#ifndef MYFS_FSHELPER_H
#define MYFS_FSHELPER_H

class FShelper {

public:

    static bool checkBlockContent(char buff[]);

};


#endif //MYFS_FSHELPER_H
