# Einrichten der Arbeitsumgebung unter Linux

Wenn Sie für das Labor eine neue Linux-Installation aufsetzen möchten, empfehlen wir Ubuntu 18.04.

Um auf einer (frischen) Ubuntu 18.04 Installation entwickeln zu können, müssen einige Pakete installiert werden. Verwenden Sie dazu die folgenden Kommandos:

	sudo apt-get update ﻿
	sudo apt-get install build-essential pkg-config fuse libfuse-dev cmake gdb valgrind doxygen
